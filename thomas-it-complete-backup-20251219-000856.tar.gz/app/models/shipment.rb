class Shipment < ApplicationRecord
end
